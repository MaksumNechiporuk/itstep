﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace House
{
  class House
    {
        public  Basement basement;
        public Walls []walls=new Walls[4];
        public Door []door=new Door[4];
        public Window window;
        public Roof roof;

    }
}
